import unittest
from core.visitor import Visitor
from core.payload import Payload
from core.dbmanager import DBManager
from core.printer import Console


class CansinaGenericTests(unittest.TestCase):
    # TODO
    pass


class VisitorTests(unittest.TestCase):
    # TODO
    pass


class PayloadTests(unittest.TestCase):
    # TODO
    pass


class DBManagerTests(unittest.TestCase):
    # TODO
    pass


class ConsoleTests(unittest.TestCase):
    # TODO
    pass


def main():
    unittest.main()

if __name__ == '__main__':
    main()
